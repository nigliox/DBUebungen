# -------------------------------------------------------------------------------------
# Schritt 1 - Tabellen erstellen
# -------------------------------------------------------------------------------------
CREATE TABLE Tracking (
  ID int NOT NULL AUTO_INCREMENT PRIMARY KEY,
  Aktion char(1),
  Benutzer varchar(255),
  Zeitstempel TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  Tabelle varchar(255),
  PKWert int
);

# -------------------------------------------------------------------------------------
# Schritt 2 - aktuellen Benutzer ermitteln
# -------------------------------------------------------------------------------------

# http://dev.mysql.com/doc/refman/5.1/de/information-functions.html
select CURRENT_USER();

# -------------------------------------------------------------------------------------
# Schritt 5 - Trigger erstellen
# -------------------------------------------------------------------------------------

# http://dev.mysql.com/doc/refman/5.1/de/create-trigger.html
CREATE TRIGGER after_mitarbeiter_insert
    AFTER INSERT ON mitarbeiter 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='I', Tabelle='mitarbeiter', Benutzer = CURRENT_USER;
CREATE TRIGGER after_mitarbeiter_update
    AFTER UPDATE ON mitarbeiter 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='U', Tabelle='mitarbeiter', Benutzer = CURRENT_USER;
CREATE TRIGGER before_mitarbeiter_delete
    BEFORE DELETE ON mitarbeiter 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='D', Tabelle='mitarbeiter', Benutzer = CURRENT_USER;

CREATE TRIGGER after_artikel_insert
    AFTER INSERT ON artikel 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='I', Tabelle='artikel', Benutzer = CURRENT_USER;
CREATE TRIGGER after_artikel_update
    AFTER UPDATE ON artikel 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='U', Tabelle='artikel', Benutzer = CURRENT_USER;
CREATE TRIGGER before_artikel_delete
    BEFORE DELETE ON artikel 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='D', Tabelle='artikel', Benutzer = CURRENT_USER;

# -------------------------------------------------------------------------------------
# Schritt 6 - SQL-Anweisungen
# -------------------------------------------------------------------------------------
insert into mitarbeiter (mitarbeiternr, name, vorname, strasse, plz, ort, gehalt, abteilung, telefonnummer, email, eintrittsdatum) values 
                        (100, 'Kehl', 'Thomas', 'Kobelbachstrasse 5', '9442', 'Berneck', 10000, 1, '0793345995', 't.kehl@symas-design.ch', current_date);
update mitarbeiter set gehalt = gehalt * 0.1 where mitarbeiternr = 100;
delete from mitarbeiter where mitarbeiternr = 100;

insert into artikel (artikelnr, bezeichnung) values (200, 'testartikel1');
insert into artikel (artikelnr, bezeichnung) values (201, 'testartikel2');
update artikel set nettopreis = 100 where artikelnr in (200, 201);
delete from artikel where artikelnr in (200, 201);

select * from tracking;
--delete from tracking;

# -------------------------------------------------------------------------------------
# Schritt 7 - Ermitteln, welche Trigger vorhanden sind
# -------------------------------------------------------------------------------------

# http://dev.mysql.com/doc/refman/5.1/de/triggers-table.html
select * from information_schema.triggers where trigger_schema = 'sqlteacherdb';

# -------------------------------------------------------------------------------------
# Schritt 8 - Trigger anpassen
# -------------------------------------------------------------------------------------

# bestehende Trigger löschen
# http://dev.mysql.com/doc/refman/5.1/de/drop-trigger.html
drop trigger after_mitarbeiter_insert;
drop trigger after_mitarbeiter_update;
drop trigger before_mitarbeiter_delete;
drop trigger after_artikel_insert;
drop trigger after_artikel_update;
drop trigger before_artikel_delete;

# Trigger neu erstellen - inkl. Primärschlüsselwert schreiben
CREATE TRIGGER after_mitarbeiter_insert
    AFTER INSERT ON mitarbeiter 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='I', Tabelle='mitarbeiter', Benutzer = CURRENT_USER, PKWert = NEW.mitarbeiternr;
CREATE TRIGGER after_mitarbeiter_update
    AFTER UPDATE ON mitarbeiter 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='U', Tabelle='mitarbeiter', Benutzer = CURRENT_USER, PKWert = NEW.mitarbeiternr;
CREATE TRIGGER before_mitarbeiter_delete
    BEFORE DELETE ON mitarbeiter 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='D', Tabelle='mitarbeiter', Benutzer = CURRENT_USER, PKWert = OLD.mitarbeiternr;

CREATE TRIGGER after_artikel_insert
    AFTER INSERT ON artikel 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='I', Tabelle='artikel', Benutzer = CURRENT_USER, PKWert = NEW.artikelnr;
CREATE TRIGGER after_artikel_update
    AFTER UPDATE ON artikel 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='U', Tabelle='artikel', Benutzer = CURRENT_USER, PKWert = NEW.artikelnr;
CREATE TRIGGER before_artikel_delete
    BEFORE DELETE ON artikel 
    FOR EACH ROW 
    INSERT INTO tracking SET Aktion='D', Tabelle='artikel', Benutzer = CURRENT_USER, PKWert = OLD.artikelnr;

#  ==> Schritt 6 wiederholen!










